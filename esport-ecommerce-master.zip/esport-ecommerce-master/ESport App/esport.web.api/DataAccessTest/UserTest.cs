﻿using ESport.Data.Entities;
using ESport.Data.DataAccess;
//using Moq;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace DataAccessTest
{
    
    public class UnitTest1
    {
        [Fact]
        public void TestMethod1()
        {
        }
    }
}
