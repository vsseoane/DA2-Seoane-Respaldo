﻿namespace ESport.Data.Commons
{
    public class PointSystemConfigurationDTO
    {
        public string PropertyName { get; set; }
        public double PropertyValue { get; set; }
    }
}
