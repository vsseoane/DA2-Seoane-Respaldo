﻿namespace ESport.Data.Commons
{

    public class RoleDTO
    {
        public string RoleId { get; set; }

        public string Description { get; set; }
        public bool Eliminated { get; set; }
    }
}
