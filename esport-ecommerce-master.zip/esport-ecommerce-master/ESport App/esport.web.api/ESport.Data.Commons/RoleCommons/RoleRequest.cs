﻿namespace ESport.Data.Commons
{
    public class RoleRequest
    {
        public string Description { get; set; }
        public string RoleId { get; set; }

    }
}
