﻿namespace ESport.Data.Commons
{
    public class ProductItemReportDTO
    {
        public string Description { get; set; }
        public int Quantity { get; set; }
        public string ProductId { get; set; }
    }
}
