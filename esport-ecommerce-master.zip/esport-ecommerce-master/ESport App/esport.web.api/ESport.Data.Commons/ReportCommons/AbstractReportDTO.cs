﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESport.Data.Commons
{
    public abstract class AbstractReportDTO
    {
        public string ReportName { get; set; }
    }
}
