﻿namespace ESport.Data.Commons
{

    public class PendingReviewDTO
    {
        public string CartItemId { get; set;}
        public string ItemDescription { get; set; }
        public string ProductId { get; set; }
    }
}
