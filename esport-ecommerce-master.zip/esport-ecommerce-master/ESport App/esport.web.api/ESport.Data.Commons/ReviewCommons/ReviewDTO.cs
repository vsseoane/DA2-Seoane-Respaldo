﻿namespace ESport.Data.Commons
{

    public class ReviewDTO
    {
        public string Description { get; set; }
        public string UserId { get; set; }
        public int Points { get; set; }
        
    }
}
