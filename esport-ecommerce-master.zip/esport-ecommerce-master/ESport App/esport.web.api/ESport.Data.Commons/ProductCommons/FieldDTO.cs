﻿namespace ESport.Data.Commons
{
    public class FieldDTO
    {
        public string FieldType { get; set; }
        public string FieldName { get; set; }
        public string FieldValue { get; set; }
    }
}
