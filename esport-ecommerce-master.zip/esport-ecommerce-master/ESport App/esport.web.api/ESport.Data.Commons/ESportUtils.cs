﻿namespace ESport.Data.Commons
{
    public class ESportUtils
    {
        public static readonly int EMPTY_LIST = ZERO;
        public static readonly int ZERO = 0;
        public static string ADMIN_ROLE = "admin";
        public static string CLIENT_ROLE = "client";
        public static string LOYALTY_PROPERTY_NAME = "loyaltyByAmount";
        
    }
}
