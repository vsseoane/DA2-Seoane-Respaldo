﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESport.Data.Entities
{
    public class Filter
    {
        public string FilterName { get; set; }
        public string FilterValue { get; set; }
    }
}
