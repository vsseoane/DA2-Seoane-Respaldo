﻿namespace ESport.Data.Entities
{
    public class CategoryReportRow
    {
        public string CategoryReport { get; set; }
        public double AVGReport { get; set; }
        public double AmountReport { get; set; }
    }
}
