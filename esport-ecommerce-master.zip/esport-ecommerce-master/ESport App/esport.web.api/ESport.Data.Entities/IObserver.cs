﻿namespace ESport.Data.Entities
{
    public interface IObserver
    {
        void Update(string message);
    }
}
