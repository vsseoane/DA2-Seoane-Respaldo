﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESport.Product.Importer
{
    public class ESportImporterUtils
    {
        public static string TXT_PRODUCT_IMPORTER = "Importar desde Txt";
        public static string XML_PRODUCT_IMPORTER = "Importar desde XML";
    }
}
