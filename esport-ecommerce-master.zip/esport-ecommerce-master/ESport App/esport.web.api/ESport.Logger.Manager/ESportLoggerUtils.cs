﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESport.Logger.Manager
{
    public class ESportLoggerUtils
    {
        public static string LOGIN_ACTION = "Login";
        public static string IMPORT_PRODUCT_ACTION = "Importación de productos";
    }
}
