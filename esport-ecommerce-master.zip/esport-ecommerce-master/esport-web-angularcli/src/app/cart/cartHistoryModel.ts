import {Cart} from './cart';

export class CartHistoryModel{
    carts:Array<Cart>;
}