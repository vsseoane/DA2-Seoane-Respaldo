export interface CartItemRequest{
    productId:string;
    quantity:number;
}