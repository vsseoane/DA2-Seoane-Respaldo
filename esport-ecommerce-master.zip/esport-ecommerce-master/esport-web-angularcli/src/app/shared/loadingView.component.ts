import { Component } from '@angular/core';


@Component({
    selector: 'loading-view',
    templateUrl: './loadingView.html'
})


export class LoadinViewComponent{
  
}