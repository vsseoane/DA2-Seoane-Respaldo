export class UrlBackendConfig{
    serverIp:string;
    serverPort:string;
    protocol:string;

    
}