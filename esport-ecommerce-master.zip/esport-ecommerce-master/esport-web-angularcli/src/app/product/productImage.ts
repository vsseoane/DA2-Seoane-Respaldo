export interface ProductImage{
    Id:string;
    Content:string;
}