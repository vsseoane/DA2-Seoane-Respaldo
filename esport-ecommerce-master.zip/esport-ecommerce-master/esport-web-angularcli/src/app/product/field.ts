export interface Field{
    FieldName:string;
    FieldType:string;
    FieldValue:any;
}