export class RoleModel{
    RoleId:string;
    Description:string;
    Eliminated:boolean=false;
}