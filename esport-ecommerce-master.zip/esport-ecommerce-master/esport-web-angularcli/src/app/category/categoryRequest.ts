export interface CategoryRequest{
    CategoryId:string;
    ProductId:string;
}