export class ReviewModel{
    CartItemId:string;
    ProductId:string;
    ItemDescription:string;
    ReviewDescription:string;
    ReviewPoints:number;
}