import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/app.module';
import { Http } from '@angular/http';


platformBrowserDynamic().bootstrapModule(AppModule);

